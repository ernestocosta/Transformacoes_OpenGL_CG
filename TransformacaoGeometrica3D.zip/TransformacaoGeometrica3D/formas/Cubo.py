from OpenGL.GL import *

vertices = [
    (0.5, -0.5, 0.5),
    (-0.5, -0.5, 0.5),
    (0.5, 0.5, 0.5),
    (-0.5, 0.5, 0.5),
    (0.5, 0.5, -0.5),
    (-0.5, 0.5, -0.5),
    (0.5, -0.5, -0.5),
    (-0.5, -0.5, -0.5)
]

arestas = [
    (0, 1), (0, 2), (0, 6),
    (2, 3), (2, 4), (3, 1),
    (3, 5), (5, 4), (5, 7),
    (1, 7), (6, 4), (6, 7)
]

def desenhaCubo():
    glBegin(GL_LINES)
    for aresta in arestas:
        for vertice in aresta:
            glVertex3fv(vertices[vertice])
    glEnd()
