from OpenGL.GL import *
import math

vertices = []
arestas = []

# Criando um prisma hexagonal
lados = 6
altura = 1
raio = 0.5

# topo e base
for i in range(lados):
    angulo = 2 * math.pi * i / lados
    x = raio * math.cos(angulo)
    z = raio * math.sin(angulo)
    vertices.append((x, altura / 2, z))     # topo
    vertices.append((x, -altura / 2, z))    # base

# arestas laterais e bases
for i in range(0, lados * 2, 2):
    arestas += [(i, i + 1), (i, (i + 2) % (lados * 2)), (i + 1, (i + 3) % (lados * 2))]

def desenhaPrisma():
    glBegin(GL_LINES)
    for aresta in arestas:
        for vertice in aresta:
            glVertex3fv(vertices[vertice])
    glEnd()

