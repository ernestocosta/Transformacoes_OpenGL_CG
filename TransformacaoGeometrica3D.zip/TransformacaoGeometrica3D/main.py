# Importa a biblioteca pygame, utilizada para criar janelas, capturar eventos e controlar o tempo
import pygame
# Importa todas as constantes do módulo pygame.locals, como DOUBLEBUF e OPENGL
from pygame.locals import *
# Importa funções da biblioteca OpenGL para renderização 3D
from OpenGL.GL import *
# Importa funções utilitárias da OpenGL, como gluPerspective
from OpenGL.GLU import *
# Importa as funções que desenham as formas geométricas
from formas.Cubo import desenhaCubo
from formas.Piramide import desenhaPiramide
from formas.Prisma import desenhaPrisma

# Dicionário que associa números a cores RGB para cada tipo de transformação
cores = {
    '1': (0, 0, 1),    # Azul - Rotação
    '2': (0, 1, 0),    # Verde - Escala
    '3': (1, 1, 0),    # Amarelo - Translação
    '4': (1, 0, 0),    # Vermelho - Espelhamento
    '5': (1, 1, 1)     # Branco - Todas juntas
}

# Exibe menu para o usuário escolher a forma geométrica
print("\n=== Escolha a Forma ===")
print("1 - Cubo")
print("2 - Pirâmide")
print("3 - Prisma")
forma = input("Forma (1-3): ")  # Recebe a escolha da forma

# Exibe menu para o usuário escolher a transformação
print("\n=== Transformações Geométricas ===")
print("1 - Rotação")
print("2 - Escala")
print("3 - Translação")
print("4 - Espelhamento")
print("5 - Todas juntas")
modo = input("Transformação (1-5): ")  # Recebe a escolha da transformação

# Inicializa o pygame
pygame.init()
# Define o tamanho da janela
screen_width, screen_height = 1000, 800
# Cria a janela com buffer duplo e contexto OpenGL
pygame.display.set_mode((screen_width, screen_height), DOUBLEBUF | OPENGL)
# Define o título da janela
pygame.display.set_caption('Transformações Geométricas')

# Função de configuração inicial da cena OpenGL
def initialise():
    glClearColor(0, 0, 0, 1)  # Define a cor de fundo (preto)
    glMatrixMode(GL_PROJECTION)  # Define a matriz de projeção
    glLoadIdentity()  # Reseta a matriz
    gluPerspective(60, (screen_width / screen_height), 0.1, 100.0)  # Define a perspectiva
    glMatrixMode(GL_MODELVIEW)  # Volta para a matriz de modelagem/visualização
    glLoadIdentity()  # Reseta a matriz
    glTranslatef(0, 0, -5)  # Move a cena para trás
    glEnable(GL_DEPTH_TEST)  # Habilita o teste de profundidade (ocultação de superfícies)

# Variáveis globais usadas nas transformações
angle, scale_factor, translation_offset = 0, 1, 0
scale_direction, translation_direction = 1, 1  # Sentidos das transformações

# Aplica transformações geométricas com base na escolha do usuário
def apply_transformations(modo):
    global angle, scale_factor, translation_offset

    if modo in ['1', '5']:  # Rotação
        glRotatef(angle, 1, 1, 0)
    if modo in ['2', '5']:  # Escala
        glScalef(scale_factor, scale_factor, scale_factor)
    if modo in ['3', '5']:  # Translação
        glTranslatef(translation_offset, 0, 0)
    if modo in ['4', '5']:  # Espelhamento
        glScalef(-1, 1, 1)

# Função que desenha a forma escolhida
def desenha_forma(forma):
    if forma == '1':
        desenhaCubo()
    elif forma == '2':
        desenhaPiramide()
    elif forma == '3':
        desenhaPrisma()

# Função principal que desenha a cena a cada frame
def display():
    global angle, scale_factor, scale_direction, translation_offset, translation_direction

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)  # Limpa a tela e o buffer de profundidade
    glLoadIdentity()  # Reseta a matriz de visualização
    glTranslatef(0, 0, -5)  # Posiciona a câmera para ver a forma

    glColor3fv(cores[modo])  # Define a cor da forma com base na transformação

    glPushMatrix()  # Salva a matriz atual
    apply_transformations(modo)  # Aplica as transformações
    desenha_forma(forma)  # Desenha a forma
    glPopMatrix()  # Restaura a matriz original

    # Atualiza valores para a próxima iteração (animação)
    angle = (angle + 1) % 360  # Incrementa o ângulo de rotação

    scale_factor += scale_direction * 0.01  # Altera o fator de escala
    if scale_factor >= 2 or scale_factor <= 0.5:
        scale_direction *= -1  # Inverte o sentido da escala

    translation_offset += translation_direction * 0.01  # Altera o deslocamento
    if abs(translation_offset) > 2:
        translation_direction *= -1  # Inverte o sentido da translação

    pygame.display.flip()  # Atualiza a tela com o novo frame

# Inicializa o contexto OpenGL
initialise()
clock = pygame.time.Clock()  # Relógio para controlar o FPS
running = True  # Controle do loop principal

# Loop principal do programa
while running:
    for event in pygame.event.get():  # Captura eventos
        if event.type == pygame.QUIT:  # Se o usuário fechar a janela
            running = False  # Encerra o loop

    display()  # Chama a função de desenho
    clock.tick(60)  # Limita o FPS em 60 quadros por segundo

# Encerra o pygame
pygame.quit()
